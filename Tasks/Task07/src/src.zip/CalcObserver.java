import java.util.*;

interface CalcObserver {
    void update(List<Item> items);
}

@ObserverRole("stats")
class StatsObserver implements CalcObserver {
    double avg;

    @Override
    public void update(List<Item> items) {
        avg = items.stream().mapToDouble(Item::getResistance).average().orElse(0);
        System.out.println("[Stats] Нове середнє: " + String.format("%.2f", avg));
    }
}

@ObserverRole("sort")
class SortObserver implements CalcObserver {
    @Override
    public void update(List<Item> items) {
        System.out.print("[Sort] ");
        items.stream()
                .mapToDouble(Item::getResistance)
                .sorted()
                .forEach(r -> System.out.printf("%.1f ", r));
        System.out.println();
    }
}