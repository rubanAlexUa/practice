import javax.swing.*;
import java.awt.*;
import java.util.List;

public class MainGUI extends JFrame {

    private final Calc calc = Calc.getInstance();
    private final StatsObserver stats = new StatsObserver();
    private final SortObserver sort = new SortObserver();

    public MainGUI() {
        super("Observer & Reflection");
        readRole(stats.getClass());
        readRole(sort.getClass());

        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(700, 480);
        setLayout(new BorderLayout());

        JPanel chart = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                draw(g);
            }
        };
        chart.setBackground(Color.WHITE);

        // кнопки
        JButton btnAdd = btn("Додати", new Color(70, 130, 200));
        JButton btnUndo = btn("Відміна", new Color(200, 140, 40));
        JButton btnClear = btn("Очистити", new Color(200, 70, 70));

        btnAdd.addActionListener(e -> {
            calc.init(1 + Math.random() * 4,
                    Math.random() * 50, Math.random() * 50, Math.random() * 50);
            refresh(chart);
        });
        btnUndo.addActionListener(e -> {
            calc.removeLast();
            refresh(chart);
        });
        btnClear.addActionListener(e -> {
            calc.clear();
            refresh(chart);
        });

        JPanel bar = new JPanel();
        bar.setBackground(new Color(235, 235, 235));
        bar.add(btnAdd);
        bar.add(btnUndo);
        bar.add(btnClear);

        add(chart, BorderLayout.CENTER);
        add(bar, BorderLayout.SOUTH);
        setLocationRelativeTo(null);
    }

    /** Оновлює спостерігачів і перемальовує графік. */
    private void refresh(JPanel chart) {
        List<Item> items = calc.getItems();
        stats.update(items);
        sort.update(items);
        chart.repaint();
    }

    /** Читає @ObserverRole через Reflection і виводить у консоль. */
    private void readRole(Class<?> c) {
        if (c.isAnnotationPresent(ObserverRole.class))
            System.out.println("Reflection: " + c.getSimpleName()
                    + " -> " + c.getAnnotation(ObserverRole.class).value());
    }

    /** Малює стовпці і лінію середнього. */
    private void draw(Graphics g) {
        List<Item> items = calc.getItems();
        int W = getWidth(), H = getHeight() - 80, pad = 40;

        // фон і осі
        g.setColor(new Color(245, 245, 245));
        g.fillRect(0, 0, W, H);
        g.setColor(Color.DARK_GRAY);
        g.drawLine(pad, pad, pad, H - pad);
        g.drawLine(pad, H - pad, W - pad, H - pad);
        g.setFont(new Font("Arial", Font.PLAIN, 11));
        g.drawString("R (Ом)", 2, pad - 5);

        if (items.isEmpty()) {
            g.setColor(Color.GRAY);
            g.setFont(new Font("Arial", Font.PLAIN, 13));
            g.drawString("Натисни «Додати»", W / 2 - 70, H / 2);
            return;
        }

        double maxR = items.stream().mapToDouble(Item::getResistance).max().orElse(1);
        int slot = (W - pad * 2) / items.size();
        int barW = Math.max(10, slot - 12);

        for (int i = 0; i < items.size(); i++) {
            double r = items.get(i).getResistance();
            int barH = (int) (r / maxR * (H - pad * 2));
            int x = pad + i * slot + (slot - barW) / 2;
            int y = H - pad - barH;

            g.setColor(new Color(70, 130, 200));
            g.fillRect(x, y, barW, barH);
            g.setColor(new Color(40, 90, 160));
            g.drawRect(x, y, barW, barH);

            g.setColor(Color.DARK_GRAY);
            g.setFont(new Font("Arial", Font.PLAIN, 10));
            g.drawString(String.format("%.0f", r), x + 2, y - 4);
            g.drawString("#" + (i + 1), x + barW / 2 - 6, H - pad + 14);
        }

        // лінія середнього
        if (stats.avg > 0) {
            int avgY = H - pad - (int) (stats.avg / maxR * (H - pad * 2));
            g.setColor(Color.RED);
            g.drawLine(pad, avgY, W - pad, avgY);
            g.setFont(new Font("Arial", Font.BOLD, 11));
            g.drawString(String.format("avg: %.0f Ом", stats.avg), W - pad - 75, avgY - 4);
        }
    }

    /** Створює кольорову кнопку. */
    private JButton btn(String text, Color color) {
        JButton b = new JButton(text);
        b.setBackground(color);
        b.setForeground(Color.WHITE);
        b.setFocusPainted(false);
        return b;
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new MainGUI().setVisible(true));
    }
}